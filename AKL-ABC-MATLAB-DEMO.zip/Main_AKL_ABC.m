%% ========================================================================
% Toy problem regarding inference of mixing coefficients of a uniform 
% mixture model using Automatic Kernel Learning ABC (AKL-ABC) 
% =========================================================================
% Authors: Wilson Gonz�lez Vanegas, M.Sc(c)
%          Andr�s Marino �lvarez Meza, PhD
%          Jos� Alberto Hern�ndez Muriel, EE
          
% Automatic Research Group, Universidad Tecnol�gica de Pereira
% =========================================================================

%% ------------ Initial configurations ------------ 
% For Matlab R2016a or latter
clc; clear;
close all;
Nabc = 1000; % Number of ABC iterations for main procedure
n = 400; % Number of observations
fig_paper = 1; % set 1: to print paper figures; 0: otherwise
addpath(genpath('EKRA-ES-master'))
addpath(genpath('klocal'))
addpath(genpath('Resources'))

%% ------------ Initialize memories ------------ 
simulated_abc = zeros(n,Nabc);
d_mmd = zeros(Nabc,1);

%% ------------ Compute synthetic observed data ------------ 
true_val = [0.25 0.04 0.33 0.04 0.34]';
observed = Sample_uniform_mixture(true_val,0:4,1:5,n);

%% ------------ Compute simulated data ------------ 
alphaDir = ones(1,numel(true_val)); % Dirichlet parameter
prior = gamrnd(repmat(alphaDir,Nabc,1),1,Nabc,numel(alphaDir)); % Sampling from a Gamma distribution
prior = prior./repmat(sum(prior,2),1,numel(alphaDir)); % Normalizing Gamma leads to a Dirichlet distribution
for i = 1:Nabc
   simulated_abc(:,i) = Sample_uniform_mixture(prior(i,:),0:4,1:5,n);
end

%% ----------- CKA-based ABC - inference using AKL-ABC -------------

% Find the number of neighbors using the LNS algorithm:
k_neigh = A_neighborhood(prior);
num_neigh_i = zeros(length(k_neigh),1);
for i = 1:length(k_neigh)
    num_neigh_i(i) = numel(k_neigh{i});
end
n_neigh = round(median(num_neigh_i));
% or manually:
%n_neigh = 7;

% Compute the similarity kernel matrix over the parameter space:
Cov = cov(prior);
d_theta = pdist2(prior,prior,'mahalanobis',Cov+1e-3*eye(size(Cov)));
[~,ind] = sort(d_theta,'ascend');
 for i = 1:size(d_theta,1)    
    d_theta(i,ind(1:n_neigh)) = pdist2(prior(i,:),prior(ind(1:n_neigh,i),:),'mahalanobis',Cov+1e-3*eye(size(Cov))); 
    d_theta(i,ind(n_neigh+1:end,i)) = inf;
 end
epsilon = 1;
Ktheta = exp(-(d_theta.^2)/epsilon);
 
% Metric Learning Stage - CKA computation:
% Summary statistics for simulations:
%nbins = round(sqrt(size(simulated_abc,1)));
%pts = linspace(min(min(simulated_abc)),max(max(simulated_abc)),n_neigh);
nbins = 10;
for i =  1 : size(simulated_abc,2)
   Ssimulated(i,:) = hist(simulated_abc(:,i),nbins);
   %Ssimulated(i,:) = [mean(simulated_abc(:,i)) var(simulated_abc(:,i)) skewness(simulated_abc(:,i)) kurtosis(simulated_abc(:,i))]; 
   %Ssimulated(i,:) = ksdensity(simulated_abc(:,i),pts); 
end
% Summary statistics for observations:
Sobserved = hist(observed,nbins);
%Sobserved = [mean(observed) var(observed) skewness(observed) kurtosis(observed)];
%Sobserved = ksdensity(observed,pts);
cmi = jet(size(Ktheta,1));
options = struct('showWindow',false,...
                 'showCommandLine',true,...
                 'lr',[1e-4 1e-5],...
                 'min_grad',1e-5,...
                 'goal',-Inf,...
                 'maxiter',50,...
                 'training','default',...
                 'Q',0.99,...
                 'init','pca',...
                 'max_fail',10);
fprintf('\n -------  Centered Kernel Alignment procedure  ---------\n')             
[A,width_cka,K2] = kMetricLearningMahalanobis(Ssimulated,Ktheta,cmi,options);

% Compute similarity kernel for setting weights: 
simulated_cka = Ssimulated*A;
observed_cka = Sobserved*A;
d_cka = pdist2(simulated_cka,observed_cka);
[~,id_sim] = sort(d_cka,'ascend');
d_cka(id_sim(n_neigh+1:end)) = inf;
W_cka = exp(-(d_cka.^2)/epsilon);
W_cka = W_cka/sum(W_cka);


%% ---- Best performance of our AKL-ABC: CKA over parameter space only ----
% Distance to target (just applicable in syntetic data):
d_target = pdist2(prior,true_val','mahalanobis',Cov+1e-3*eye(size(Cov)));
[~,it] = sort(d_target,'ascend');

% Compute similarity kernel for setting weights
d_target(it(n_neigh+1:end)) = inf;
W_theta = exp(-(d_target.^2)/epsilon);
W_theta = W_theta/sum(W_theta);

%% ----------- MMD-based ABC: K2ABC algorithm -------------
% Define bandwidth for characteristic kernel in MMD estimator
% Manually:
smmd = 0.1; % Setting this value requires an expensive grid search. See Park et al.
% Or using the median over the data:
% for t = 1:Nabc    
%     d_s(:,t) = pdist(simulated_abc(:,t));
%     [~,ii] = sort(d_s(:,t),'ascend');
%     d_sr(:,t) = d_s(ii(1:n_neigh),t);
% end
% smmd = max(max(d_sr));

fprintf('\n ------ K2ABC-based inference stage ------ \n')

% Compute distance over distribution using the MMD estimator:
for t = 1:size(simulated_abc,2)
    fprintf('K2-ABC iteration %d/%d\n',t,size(simulated_abc,2))
    d_mmd(t) = MMD2(simulated_abc(:,t),observed,smmd,'truncated');
end

% Compute simmilarity kernel for setting weights:
epsilon_Kw = 0.001; % Setting this value requires an expensive grid search. See Park et al.
W_mmd = exp(-d_mmd/epsilon_Kw);
W_mmd = W_mmd/sum(W_mmd); 


%% ----------- Compute posteriors and see performances -------------
% Expected value of posteriors:
true_theta = prior'*W_theta;
true_mmd = prior'*W_mmd;
true_cka = prior'*W_cka;

% Assess index error:
err1 = norm(true_theta-true_val);
err2 = norm(true_mmd-true_val);
err3 = norm(true_cka-true_val);

fprintf('\n --------- Index error ---------\n')
fprintf(' Best \t\t K2-ABC \t\t AKL-ABC \n')
fprintf('%-10.4f \t %-10.4f \t %-10.4f\n',err1,err2,err3)

% Additional figures

% figure; hold on;
% stem(W_theta,'filled')
% stem(W_mmd,'filled')
% stem(W_cka,'filled')
% legend('W_{\theta}','W_{MMD}','W_{cka}')

% figure
% bar([true_val';true_theta';true_mmd';true_cka'])
% set(gca,'Xticklabels',{'Target','\theta_\theta','\theta_{MMD}','\theta_{cka}'})
% title(['E_\theta=' num2str(err1) '---E_{MMD}=' num2str(err2) '---E_{cka}=' num2str(err3)])
% showfigs_c(3)

%% Figures for paper:
if fig_paper      
    id_nonzero_theta = find(W_theta);
    id_nonzero_cka = find(W_cka);
    figure; hold on; set(gca,'fontsize',22);
    stem(id_nonzero_theta,W_theta(id_nonzero_theta),'filled','marker','s','markersize',14,'linewidth',2)
    stem(id_nonzero_cka,W_cka(id_nonzero_cka),'filled','markersize',12,'linewidth',2); box on;
    xlabel('Index'); ylabel('W_n'); xlim([0 Nabc]); ylim([0 0.3]);
    set(gca, 'YGrid', 'on', 'XGrid', 'off')
    set(gca,'Xtick',0:100:1000)
    legend('Best candidate','AKL-ABC simulation','Location','northeast')
    
    x0=10;
    y0=10;
    width=800;
    height=480;
    set(gcf,'units','points','position',[x0,y0,width,height])
    
    figure;
    bar([true_val';true_theta';true_mmd';true_cka']); box on;
    ylim([0 0.41])
    set(gca,'fontsize',22);
    set(gca,'Xticklabels',{'Target','Best','K2-ABC','AKL-ABC'})
    set(gca, 'YGrid', 'on', 'XGrid', 'off')
    ylabel('E[\pi_n|y]')
    legend(' \pi_1',' \pi_2',' \pi_3',' \pi_4',' \pi_5','Location','northwest','Orientation','horizontal')
    
    x0=10;
    y0=10;
    width=800;
    height=480;
    set(gcf,'units','points','position',[x0,y0,width,height])
    showfigs_c(2)
end