%Encontrar elementos diferentes entre ik1 e ik2, de acuerdo al numero
%de vecinos k

function [nvd]=A_vecd(ik1,ik2,k)

nvd=0;
for i=1:k
    ie=sum(ik1(1:k)==ik2(i)); %encontrar vecino
    if ie<1 %vecino no comun
        nvd=nvd+1;
    end
end