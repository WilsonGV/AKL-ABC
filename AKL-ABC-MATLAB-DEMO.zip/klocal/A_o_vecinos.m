%Obtener indices de vecinos organizados del mas cercano al mas lejano de X
%ik: indice de vecinos mas cercanos por columnas (n-1)xn
%D: matriz de distancias Euclideas

function [ik,D]=A_o_vecinos(X,o)

n=size(X,1);

display('Hallando distancias Euclideas...');
D=pdist2(X,X,'mahalanobis',cov(X)+1e-3*eye(size(X,2))); %matriz distancias euclidianas nxn
%organizar segun vecinos mas cercanos desendente
display('Organizando vecinos mas cercanos...');
ik=zeros(n,n);
for i=1:n
    %i
    D(i,i) = inf;

    [Dk ik(:,i)]=sort(D(i,:),'ascend');

    if o == 1
        [vu, ivu] = unique(Dk, 'first');

        for j = 1 : length(vu)
            if i == 287
                a = 0;
            end
            %% identifica distancias min iguales
            idi = find(Dk == Dk(ivu(j)));
            veci = [i;ik(idi,i)];
            did = dist(veci');
            [tm odid] = sort(did(2:end,1),'ascend');
            ik(idi,i) = ik(idi(odid),i);
        end
    end
end

clc
clear Dk