%LLE
%Entradas:
%X: matriz de entrada (nxD)
%k: numero vecinos mas cercanos
%d: dimension de salida
%tr: 1-> saul 0.1, 2-> automatico, 3->deRidder02
%--------------------------------------------------------------------------
%Salidas
%Y: Vectores de salida (nxd)
%W: Pesos de entrenamiento
%--------------------------------------------------------------------------
function [Y W]=A_lle_l(X,kl,d,tr)
[n p]=size(X);
%ciclo principal
display('Obteniendo pesos...');
%matriz de Pesos
W=zeros(n);
%matriz m
%-------------------------------------------------------------------------
for i=1:n
    i
    k=length(kl{i});
    %matriz gram
    posi=kl{i};

    G_i=repmat(X(i,:),k,1)-X(posi,:);
    G=G_i*G_i';

    %si no es necesario regularizar
    if tr==0%abs(det(G)) > 1e-8
        w = sum(inv(G),2);
        lambda = 1/sum(w);
        w = lambda*w;
        %alfa(i,1) = 0;
        clear lambda
    elseif tr==1
        % Regularizaci�n empleada en [SAUL03]
        delta = 0.1;
        alpha = ((delta^2)/k)*trace(G);
        %alfa(i,1) = alpha;
        % se calculan los pesos para los vecinos del i-�simo punto
        w = sum(inv(G+alpha*eye(k)),2);
        lambda = 1/sum(w);
        w = lambda*w;
        clear delta alpha lambda

       

    elseif tr==2
        %automatica
        display('Hallando cota minima...');

%         [U,S] = eig(G);
%         ds=diag(S);
%         ds=ds(ds>1e-16);
%         minr = min(ds);
%         maxr = max(ds);
        
        alpha = fminbnd(@(alpha) A_regulerror(alpha,G),eps,1);
        clc
        val1 = G+alpha^2*eye(size(G));
        val2 = ones(1,k)*((2*val1)\ones(k,1));
        lambda = 1/val2;
        w1 = lambda*((2*val1)\ones(k,1));
        clear val1 val2 lambda
        w = w1;
        %alfa(i,1) = alpha;
        clear alpha w1
    elseif tr==3
        % Regularizaci�n empleada en [deRidder02]
        C = (G_i'*G_i)/n;
        [vec,val] = eig(C);
        valp = diag(val);
        clear val vec
        valp = sort(valp,'descend');
        alpha =  sum(valp(d+1:p))/(p-d);
        %alfa(i,1) = alpha;
        w = sum(inv(G+alpha*eye(k)),2);
        lambda = 1/sum(w);
        w = lambda*w;
        clear delta alpha lambda vec val
    end
    W(i,posi) = w';
    clear w delta G G_i
end
%fin ciclo principal paso 2
%-------------------------------------------------------------------------
%sw=sum(W,2); comprobar sumas de pesos =1
display('Hallando eiginventores...');
%--------------------------------------------------------------------------
%hallar eigenvalores M=(I-W)'(I-W)
I=eye(n);
M=(I-W')*(I-W);
% clear I W posi
%--------------------------------------------------------------------------
[Y Val]=eig(full(M));

[Va iv]=sort((diag(Val)),'ascend'); %Va valores propios organizados de menor a mayor
Y = Y(:,iv);

%--------------------------------------------------------------------------
Y(:,diag(Val)<1e-12) = [];

stdv = std(Y);
stdv = stdv/max(stdv);
Y(:,stdv<0.99)=[];
% [tm im] = min(stdv);
% if 100*tm/mean(Y(:,im)) < 0.1
%     Y(:,im) = [];
% end
%--------------------------------------------------------------------------
%Obtener las d-dimensiones en Yi
Y=Y(:,1:d);
%Y=Y(:,2:d+1);
clear Val iv
%fin paso 3
%--------------------------------------------------------------------------
