%Encontrar klocal para cada xi
%---------------------------------------------------------
%%Entradas:
%kmin: kmin de conexion (lle_klocal_grafos)
%kmax: k maximo para depuracion de vecindarios
%ikg: indices de vecinos mas cercanos segun distancia geodesica
%ikx: indices de vecinos mas cercanos segun distancia euclidea
%Dx: distancia euclides
%DGc: distancia geodesica
%%Salidas
%nvd: numero de vecinos diferentes entre Dx y DGc para cada posible k
%indk: numero de vecinos por punto
%ind2: numero de vecinos con suavizado por vecindario
%indf: con suavizado por vecindario y media total de vecinos
%kl: cell con los vecinos de cada punto (usarse en lle_ae)
%di: dimension de cada vecindario segun pca
%d: dimension maxima
%lambdat: stress de shanoon de xi para cada posible k

function [kl indf nvd indk ind2 dn]=A_klocal(kmin,kmax,X,ikg,ikx,hd)

n=size(X,1);

%klocal
indk=zeros(1,n);
nvd=zeros(kmax,n);

%% encontar k para cada punto q cumpla con condicion establecida
for i=1:n
    %i
    for j=kmin+1:kmax
        k=j;
        nvd(k,i)=A_vecd(ikx(:,i),ikg(:,i),k)/k; %vecinos diferentes entre i con de y dg
    end
end
clc

%% k por min
for i=1:n    
    indk(i)=kmin+find(nvd(kmin+1:end,i)==min(nvd(kmin+1:end,i)),1,'last');
end

%% alinear vecindario i con sus vecinos mas cercanos
ind2=zeros(1,n);
for i=1:n
    vs=[];
    for j=1:indk(i)
        vs=[vs indk(ikx(j,i))];
    end
   % ind2(i)=round(mean([indk(i) vs]));
   ind2(i)=round(mean([vs indk(i)]));
end
clc
%% deteccion de outliers en k con alpha=0.05 outliers reemplazados x media
in2={ind2'};
[indo xnf] = A_atipico_ic(in2,0.05); %CON INTERVALO DE CONFIANZA 5%
% [indo xnf] = ATIPICOS(in2); %CON RELACION >4.5
indo=indo{1}==1;
indf=ind2;
indf(indo)=round(mean(xnf{1}));

clc

% Hallar vecinos de cada punto y dimension intrinsica
dn=zeros(n,1);
kl=cell(n,1);
for i=1:n    
    kl{i,1}=ikx(1:indf(i),i);
    if hd==1 %hallar dimension de salida
        [Val]=A_pca_gra(X(kl{i,1},:));
        %segun varianza v
        v=0;
        lv=length(Val);
        for j=0:lv-1
            v=v+Val(end-j);
            if v>=0.95
                dn(i,1)=j+1;
                break
            end
        end
        clear Val
    else
        dn=[];
    end
end
