% Identificacion de outliers por intervalos de confianza
% Entradas:
% X: cell , en cada campo una matriz de datos filas (observaciones) x
% columnas (caracteristicas) para cada clase

% Salidas
% indi: matriz que identifica elementos outliers de la clase
% idc: identifica cuales fueron las variables (columnas) en las que hab�a
% m�s de 10% outliers
% Xnco: matriz de observaciones x variables (sin las variables (columnas) que se
% eliminaron por poseer m�s de 10% de valores at�picos.
% idfl: identifica las observaciones (filas) se�aladas con outliers.
% Xnfo: es la matriz original pero no posee las filas correspondientes a
% muestras identificadas como atipicas.
% Xno: es la matriz sin variables con m�s de un 10% de outliers y sin
% filas que fueran outliers.

function [indi,Xnfo,idfl] = A_atipico_ic(X,alfa)

nc = length(X); %# campos
indi=cell(nc,1);

%-------------------------------------------------------------------------
for c = 1:nc  %recorrer cell de X

    [n,p] = size(X{c,1}); %n #filas - p #columnas
    indi{c,1} = zeros(n,p); %no

    if n<=25


        for i = 1:p %recorrer columnas

            Xtc=X{c,1}(:,i);         %Copiar datos a trabajar sin borrar elementos
            Xtc2=X{c,1}(:,i);        %Copiar datos a trabajar para borrar elementos

            for j = 1:n %recorrer filas

                m = length(Xtc2);   %#elementos al ir eliminando outlier
                mabs=norm(Xtc,inf); %algoritmo 1
                num = abs(mabs-median(Xtc2));
                den = std(Xtc2)*sqrt((m-1)/m);
                tst = icdf('t',1-alfa/2,m-1);  %t_1-0.025{n-1}  t-Student

                if num/den > tst        %si se debe remover
                    if mabs == abs(min(Xtc)) %si el max abs es el minimo
                        [val,ind] = min(Xtc);    %identifica indice
                        [val2,ind2] = min(Xtc2);
                    else
                        [val,ind] = max(Xtc);
                        [val2,ind2] = max(Xtc2);
                    end

                    indi{c,1}(ind,i) = 1;
                    Xtc(ind,:)  = NaN;    %eliminar atipico en vector copia
                    Xtc2(ind2,:) = [];  %eliminar en vector copia 2 para volver a itera
                else break;
                end
            end
        end

    else  %fin n<=25

        for i = 1:p %recorrer columnas

            Xtc=X{c,1}(:,i);         %Copiar datos a trabajar sin borrar elementos
            Xtc2=X{c,1}(:,i);        %Copiar datos a trabajar para borrar elementos

            for j = 1:n %recorrer filas

                m = length(Xtc2);   %#elementos al ir eliminando outlier
                mabs=norm(Xtc,inf); %algoritmo 1
                xi = abs(mabs-abs(median(Xtc2)))/std(Xtc2);
                tst = icdf('t',1-alfa/2,m-2);  %[alpha=0.1,n]
                xg = tst*sqrt(m-1)/(sqrt(m-2+(tst)^2));

                if xi > xg        %si se debe remover

                    if mabs == abs(min(Xtc)) %si el max abs es el minimo
                        [val,ind] = min(Xtc);    %identifica indice
                        [val2,ind2] = min(Xtc2);

                    else   [val,ind] = max(Xtc);
                        [val2,ind2] = max(Xtc2);
                    end

                    indi{c,1}(ind,i) = 1;
                    Xtc(ind,:)  = NaN;    %eliminar atipico en vector copia
                    Xtc2(ind2,:) = [];  %eliminar en vector copia 2 para volver a iterar
                else break;
                end
            end
        end
    end %fin if n

    %-----------------------------------------------------------------------------
    idfl{c,1} = sum(indi{c,1},2)>=1; %identifica algun outlier en fila
    idcl(c,:) = sum(indi{c,1},1).*100./n > 10;   %verificar  columna con 10% outliers


    Xnfo{c,1} = X{c,1};
    Xnfo{c,1}(idfl{c,1},:) = [];

end %fin for nc

% ic = sum(idcl,1) >= 1; %retorna suma de cada columnas y compara con 1
% idc = find(ic == 1); %identifica posicion de columna outlier
%
% for c = 1:nc
%
%     Xnco{c,1} = X{c,1};
%     Xnco{c,1}(:,ic) = [];
%     Xno{c,1} = Xnfo{c,1};
%     Xno{c,1}(:,ic) = [];  %sin filas sin columnas outliers
%
% end
% clear Xtc Xtc2 ic n p

fprintf('outliers x intervalo de confianza.\n')
%close(h)



% elaborado por : andres y juli - un 2008-1
