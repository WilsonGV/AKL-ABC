%% ========================================================================
% Sampling from a mixture of uniform distributions
% =========================================================================
% Author: Wilson Gonz�lez Vanegas, M.Sc(c)
% Automatic Research Group, Universidad Tecnol�gica de Pereira
% =========================================================================
% Inputs: p: vector with mixing coefficents. p \in R^c
%         a: minimum values for each uniform distribution. a \in R^c
%         b: maximum values for each uniform distribution. a \in R^c
%         n: number of samples to draw from the mixture. n \in R
%
% Outputs: samples: vector with n samples drawn from the uniform mixture model.
%% =========================================================================


function samples = Sample_uniform_mixture(p,a,b,n)
if sum(p) < 0.99 && sum(p) > 1.01
    error('Components of vector p must sum to unity')
end
if size(n,1) > 1 || size(n,2) > 1 
    error('The number of samples n must be a scalar')
end
id_comp = mnrnd(1,p,n);
num_comp = numel(p);
samples = zeros(n,1);

for c = 1:num_comp
    id_aux = find(id_comp(:,c));
    samples(id_aux) = unifrnd(a(c),b(c),numel(id_aux),1);
end

