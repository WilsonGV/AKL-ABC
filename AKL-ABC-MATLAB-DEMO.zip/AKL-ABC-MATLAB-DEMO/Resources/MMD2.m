%% ========================================================================
% Compute the Maximum Mean Discrepancy between two distributions in terms
% of their samples using a Gaussian kernel.
% =========================================================================
% Author: Wilson Gonz�lez Vanegas, M.Sc(c)
% Automatic Research Group, Universidad Tecnol�gica de Pereira
% =========================================================================
% Inputs: A: Sample distribution 1; A = {a_i}, i = 1:na ~ P_A 
%         B: Sample distribution 2; B = {b_j}, j = 1:nb ~ P_B
%         bw: Bandwidth of the Gaussian kernel. Options are:
%               - bw \in R, na = nb or na ~= nb.
%               - bw \in R^{L x 1}, na = nb.
%               - bw \in R^{L x L}, na = nb.
%         option: set 'truncated' to use the unbiased estimator of MMD
%                 according to Gretton et al. Otherwise, use 'full'.
%               
%             Both, a_i and b_j, must be same length L.
%             Size(A) = na x L   and  Size(B) = nb x L.
% 
% Output: MMD: Computation of MMD^2(P_A,P_B).
%% ========================================================================
function MMD = MMD2(A,B,bw,option)

%% Look for possible errors:
[na,la] = size(A);
[nb,lb] = size(B);
[bw_r, bw_c] = size(bw);
if na == nb
    if bw_r == bw_c && bw_r > 1
        if bw_r ~= na
            error('The size of bw must be samples x samples')
        end
    end
    if bw_r == 1 && bw_c == na
        bw = bw';
    end
end
if la ~= lb
    error('The number of columns in A and B must be the same')
end

%% Mean procedure:
d_AA = pdist2(A,A);
d_BB = pdist2(B,B);
d_AB = pdist2(A,B);

if (bw_r + bw_c) == 2 % bw \in R
    ha = bw*ones(na,na);
    hab = bw*ones(na,nb);
    hb = ha;
elseif bw_r > bw_c && na == nb % bw \in R^{L x 1}
%     ha = repmat(bw,1,na);
%     hab = ha; 
%     hb = ha;
    ha = diag(bw) + median(bw)*ones(numel(bw)) - diag(median(bw)*ones(numel(bw),1));
    hab = ha; 
    hb = ha;
elseif bw_r == bw_c && na == nb % bw \in R^{L x L}. Procedure based on CKA
    ha = bw; hb = bw; hab = bw;
else
    error('Dimensions of A, B & bw are in trouble');
end


K_AA = exp(-(d_AA.^2)./(2*ha.^2));
K_BB = exp(-(d_BB.^2)./(2*hb.^2));
K_AB = exp(-(d_AB.^2)./(2*hab.^2));

if strcmp(option,'truncated')
    term_AA = sum(sum(K_AA)) - sum(diag(K_AA));
    term_BB = sum(sum(K_BB)) - sum(diag(K_BB));
    term_AB = sum(sum(K_AB));
    MMD = 1/(na*(na-1))*term_AA + 1/(nb*(nb-1))*term_BB - 2/(na*nb)*term_AB;
elseif strcmp(option,'full')
    term_AA = sum(sum(K_AA));
    term_BB = sum(sum(K_BB));
    term_AB = sum(sum(K_AB));
    MMD = 1/(na*na)*term_AA + 1/(nb*nb)*term_BB - 2/(na*nb)*term_AB;
end
