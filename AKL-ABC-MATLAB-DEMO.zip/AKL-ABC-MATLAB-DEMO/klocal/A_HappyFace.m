%add graph toolbox
clc, close all
ppath = 'toolbox_grafos';
addpath(genpath(ppath));
% SWISS ROLL DATASET
% load swiss_roll
load HappyFace
%   N=1000;
% % GENERATE SAMPLED DATA
%   tt = (3*pi/2)*(1+2*rand(1,N));  height = 21*rand(1,N);
%   X = [tt.*cos(tt); height; tt.*sin(tt)];
%   X = X';
  
%neigborhood identification - graph analysis ->kl{i} neighbors of vertex i
kl = A_neighborhood(X);

%% visualization on synthetic data
%Manifold learning
% d = 2;
% tr = 1;
% [Y W] = A_lle_l(X,kl,d,tr);
% [tm ind] = sort(Y(:,1));
% Y = Y(ind,:);
% X = X(ind,:);

subplot(1,2,1)
A_pdeg(X);
subplot(1,2,2)
A_pdeg(X);
A_pdeg_g(X,kl)
