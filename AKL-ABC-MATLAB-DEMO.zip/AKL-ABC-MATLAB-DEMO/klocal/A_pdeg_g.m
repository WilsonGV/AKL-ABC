%Graficar degradado
%X=datos
%d=dimension de grafica
%X debe estar organizado

function A_pdeg_g(X,kl)

[n p]=size(X);
%organizar datos
%[X1(:,3),id1] = sort(X(:,3),'ascend');
%X1(:,1) = X(id1,1);
%X1(:,2) = X(id1,2);
X1=X;
%------------------------------------------------------------------------
%graficar datos
%------------------------------------------------------------------------
%Grafica 3-D

if p==3
    display('Graficando 3-D...');
    view(10,10)
    cm=colormap(jet(n));
    hold on
    grid off
    for i=1:n
        %plot3(X1(i,1),X1(i,2),X1(i,3),'o','MarkerSize',4,'MarkerEdgeColor',cm(i,:),'MarkerFaceColor',cm(i,:));
        display(['Drawing neighborhood vertex ' num2str(i) ' of ' num2str(n)])
        for j = 1 : numel(kl{i})
            line([X1(i,1) X1(kl{i}(j),1)]...
                ,[X1(i,2) X1(kl{i}(j),2)],...
                [X1(i,3) X1(kl{i}(j),3)],'Marker','.','LineStyle','-')
            drawnow
            
        end
        
        
    end
    axis tight
    %fin 3-D
    %--------------------------------------------------------------------------

elseif p==2
    display('Graficando 2-D...');
    hold on
    grid off
    cm=colormap(jet(n));
    for i=1:n
        plot(X1(i,1),X1(i,2),'o','MarkerSize',4,'MarkerEdgeColor',cm(i,:),'MarkerFaceColor',cm(i,:))
         for j = 1 : numel(kl{i})
            line([X1(i,1) X1(kl{i}(j),1)]...
                ,[X1(i,2) X1(kl{i}(j),2)],...
                'Marker','.','LineStyle','-')
           % drawnow
            
        end
       
    end
    axis tight

elseif p==1
    display('Graficando 2-D (1)...');
    hold on
    grid off
    cm=colormap(jet(n));
    for i=1:n
        plot(X1(i,1),'o','MarkerSize',5,'MarkerEdgeColor','k','MarkerFaceColor',cm(i,:))
    end
else
    display('Dimension no valida')
    p
end

%--------------------------------------------------------------------------


