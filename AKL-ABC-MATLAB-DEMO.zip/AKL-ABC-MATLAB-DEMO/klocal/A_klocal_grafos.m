%%Hallar estructura de variedad por distancia geodesica
%Entradas: X: matriz con datos de entrada
%Salidas:
%Dx: distancia euclidea
%DGc: Distancia geodesica
%kmin: k minimo de coneccion del grafo
%ikx: indice de vecinos mas cercanos segun distancia euclidea
%columnas xi, filas vecinos mas cercanos de xi  x(1,10): 10 vecino de x1
%ikg: indice de vecinos mas cercanos segun distancia geodesica
%E: matriz adyasencia del grafo

%%------------------------------------------------------------------------
function [Dx DGc kmin kmax ikx ikg E] =A_klocal_grafos(X,o)
clc
n=size(X,1);
%% hallar distancias euclideas
[ikx Dx] = A_o_vecinos(X,o);
INF =  inf;  %% effectively infinite distance
%% Contruyendo grafo x vecindario-------------------------
disp('Construyendo grafos...');
DG=Dx;
[tmp, ind] = sort(DG,'ascend'); %Organizar distancias ascendente
clear tmp
va=0;
kmin=[];
clc
%% distancia infinita vertices q no pertenecen al vecindario
for kg=1:n
    DG=Dx;
    for i=1:n
        DG(i,ind((2+kg):end,i)) = INF; %vecinos no cercanos segun kglobal distancia inf
    end
    DG = min(DG,DG');    %% Make sure distance matrix is symmetric
    %conectividad en el grafo
     E = (1-(DG==INF));
     E=E.*(eye(n)==0);
    % BFS Compute the breadth first search order.
    %recorrer grafo y verificar coneccion, si d(i)<0 vertice no alcanzable
    d=zeros(n);
    %kg
    for j=1:n
        %j
        [d(:,j)] = bfs(sparse(E),j);
        dn=find(d<0,1,'first');
        if isempty(dn) ~= 1 %algun vertice no conectado
            break; %probar con el siguiente k
        end
        if j==n
            va=1;
        end
    end %todos los vertices alcanzable kg=kmin de coneccion del grafo
    if va==1
        kmin=kg;
        break;
    end
    clc
end

if va==0
    disp('Ningun k para coneccion del grafo')
else

   % disp('Hallando caminos mas cortos...')
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %distancia exacta - mas costoso computacionalmente
    %[DP P]=all_shortest_paths(sparse(E),struct('algname','floyd_warshall'));
    % disp('Hallando recorridos y distancia geodesica con caminos mas cortos...')
    %[po DGc]=caminos(P,Dx);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %clear po
    % [DGc]=all_shortest_paths(sparse(E)); %lo mismo q bfs
    DGc=d;

    disp('Organizando Vecinos segun distancia geodesica...')
    ikg=zeros(n);
    for i=1:n
        DGc(i,i) = inf;
        [Dk ikg(:,i)]=sort(DGc(:,i),'ascend');
      
    end
    
end
%po: caminos de cada punto
%clear Dp 
%% identificar kmax
 kmax=round((n/(nnz(E))/2)*(n/(kmin)));%*(ceil(n/1000)))));
%kmax = ceil((2-(nnz(E)/(n*(n-1))))*kmin);
%%% ojoooo
% kmax = kmin;
% kmin = 2;
% if kmax <= kmin
%     kmax = kmin + 1;
% end
% fprintf('n^2= %2.3f \nN�mero aristas= %2.3f \nValor de Kmin = %2.3f \nValor Kmax = %2.3f',n^2,nnz(E),kmin,kmax)
% pause
if kmax >=n %Si kmax mas grande q numero de datos
    kmax=round(n-n*0.2);
elseif kmax <=kmin
    kmax=kmin+1;
end
clc