function g2 = A_regulerror(alpha,G)

k = length(G);
val1 = G+alpha^2*eye(size(G));
val2 = ones(1,k)*((2*val1)\ones(k,1));
lambda = 1/val2;
w = lambda*((2*val1)\ones(k,1));
f2 = norm(w)^2+lambda^2;
g2 = log10(f2);

clear k val1 val2 lambda w f2