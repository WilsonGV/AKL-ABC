%PCA
%Xp: matriz de entrada de tama�o (nxp)
%d: Si d>1 numero dimensiones de salida, si 0<d<1 porcentaje varianza retenida

function [Y meanv stdv W Val Vec]=A_pca(X,d)

%centralizar muestras
display('Realizando PCA...')
[n p]=size(X);
Xpp=X;
stdv = std(Xpp);
meanv = mean(Xpp);
stdv(stdv==0) = 1;
Xpp=(Xpp-repmat(meanv,n,1))./repmat(stdv,n,1);

if n>p
    P=Xpp'*Xpp; %tam�o pxp
else
    P=Xpp*Xpp'; %tama�o nxn
end

[Vec Val]=eig(P);
Val = abs(diag(Val));
Val = Val./sum(Val);
%organizar de mayor a menor
[Val ival]=sort(Val,'descend');
Vec = Vec(:,ival);

if d == 0 %valores propios mayores a la media de la suma de los valores propios
    ivald = Val >= mean(Val);
    W = Vec(:,ivald);

elseif d > 0 && d < 1
   
    va = 0;
    W = [];
    i = 1;
    while va < d
        W = [W,Vec(:,i)];
        va = va+Val(i);
        i=i+1;
    end

elseif d >=  1
    W = Vec(:,1:d);
end

if n<p
    W = Xpp'*W;
end
Y = Xpp*W;
