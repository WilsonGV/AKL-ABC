function kl = A_neighborhood(X)

[Dx DGc kmin kmax ikx ikg E] =A_klocal_grafos(X,0);
%kmin = 7;
[kl indf nvd indk ind2 dn]=A_klocal(kmin,kmax,X,ikg,ikx,0);
